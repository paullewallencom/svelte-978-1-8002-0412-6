<script>
  import Navbar from "./Sections/Navbar.svelte";
</script>

<Navbar />
