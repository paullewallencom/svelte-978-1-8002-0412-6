<script>
  export let title = "Default title";
</script>

<style>
  nav {
    width: 100%;
    font-size: 2rem;
    padding: 0.5rem 0;
    background-color: #333;
    color: #fff;
    text-align: center;
  }
</style>

<nav>{title}</nav>
