<script>
  import Kanban from "../components/Sections/Kanban.svelte";
</script>

<svelte:head>
  <title>Kanban Motion - Board 2</title>
</svelte:head>

<Kanban databaseURL="https://kanban-motion.firebaseio.com/Board 2.json" />
