<script>
  import Kanban from "../components/Sections/Kanban.svelte";
</script>

<svelte:head>
  <title>Kanban Motion - Board 1</title>
</svelte:head>

<Kanban databaseURL="https://kanban-motion.firebaseio.com/Board 1.json" />
