<script>
  import Kanban from "../components/Sections/Kanban.svelte";
</script>

<Kanban />
