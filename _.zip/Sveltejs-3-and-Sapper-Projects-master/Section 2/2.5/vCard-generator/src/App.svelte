<script>
  import Navbar from "./Sections/Navbar.svelte";
  import Form from "./UI/Form.svelte";
</script>

<Navbar title="vCard Generator" />

<Form />
