<script>
  export let QRCode = false;
</script>

<style>
  section {
    width: 400px;
    height: 200px;
    padding: 1rem 2rem;
    margin: 2rem auto 0 auto;
    border-radius: 10px;
    position: relative;
    display: flex;
    justify-content: space-between;
    color: white;
    box-shadow: 0 1px 3px hsla(0, 0%, 0%, 0.12), 0 1px 2px hsla(0, 0%, 0%, 0.24);
    background: linear-gradient(
      to bottom right,
      rgba(16, 24, 26, 1),
      rgba(33, 87, 145, 1)
    );
    background-size: cover;
  }
</style>

<section>{QRCode}</section>
