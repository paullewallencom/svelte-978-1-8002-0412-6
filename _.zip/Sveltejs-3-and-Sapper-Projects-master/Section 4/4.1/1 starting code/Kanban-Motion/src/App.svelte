<script>
  import Navbar from "./Sections/Navbar.svelte";
  import Kanban from "./Sections/Kanban.svelte";
</script>

<style>
  main {
    padding: 1rem;
  }
</style>

<Navbar />

<main>
  <Kanban />
</main>
